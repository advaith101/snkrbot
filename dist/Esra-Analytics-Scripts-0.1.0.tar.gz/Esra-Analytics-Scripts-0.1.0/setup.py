from setuptools import setup

setup(
    name='Esra-Analytics-Scripts',
    version='0.1.0',    
    description='Analytics Scripts for Esra Web App',
    url='https://github.com/advaith101/esra-api',
    author='Esra Systems LLC',
    author_email='info@esrasystems.com',
    license='BSD 2-clause',
    install_requires=[
                      'mysql.connector',
                      'pandas',
                      'numpy',
                      'datetime',
                      'matplotlib',
                      'plotly',
                      'seaborn'
                      ],

    classifiers=[     
        'Programming Language :: Python :: 3.5',
    ],
)